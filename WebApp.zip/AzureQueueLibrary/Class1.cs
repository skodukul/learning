﻿using System;

namespace AzureQueueLibrary
{
    public class Class1
    {
    }
}
