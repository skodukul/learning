﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace AzureQueueLibrary.MessageSerializer
{
    public interface IMessageSerializer
    {
        T Deserialize<T>(string message);

        T Serialize<T>(string message);
    }

    public class JsonMessageSerializer : IMessageSerializer
    {
        public T Deserialize<T>(string message)
        {
            var obj = JsonConvert.DeserializeObject<T>(message);
        }

        public T Serialize<T>(string message)
        {
            throw new NotImplementedException();
        }
    }
}
