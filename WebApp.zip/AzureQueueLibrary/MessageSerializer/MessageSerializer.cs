﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AzureQueueLibrary.MessageSerializer
{
    class MessageSerializer
    {
    }
}
