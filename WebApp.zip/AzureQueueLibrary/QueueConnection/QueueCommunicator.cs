﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AzureQueueLibrary.QueueConnection
{
    public interface IQueueCommunicator
    {
        T Read<T>(string message);

        Task SendAsync<T>(T obj);

    }
    public class QueueCommunicator : IQueueCommunicator
    {
        public T Read<T>(string message)
        {
            throw new NotImplementedException();
        }

        public Task SendAsync<T>(T obj)
        {
            throw new NotImplementedException();
        }
    }
}
